//Programa 1: Suponha que v é um vetor. Descreva a diferença conceitual entre as expressões v[3] e *(v+3).

// C fornece dois tipos de metodos para acessar elementos de matrizes: 
// indexação de matrizes (v[i]) e aritmética de ponteiros *(v+i).
// Os dois são semanticamente parecidos, mas a aritimética de ponteiros pode ser mais rápida
//que a indexação de matrizes.